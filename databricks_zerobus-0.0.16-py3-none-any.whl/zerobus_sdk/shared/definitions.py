from google.protobuf.descriptor import Descriptor
from typing import Callable, Optional
from enum import Enum
import grpc

from .zerobus_service_pb2 import IngestRecordResponse

NOT_RETRIABLE_GRPC_CODES = {
    grpc.StatusCode.INVALID_ARGUMENT,
    grpc.StatusCode.NOT_FOUND,
    grpc.StatusCode.UNAUTHENTICATED,
    grpc.StatusCode.OUT_OF_RANGE,
}


class TableProperties:
    """
    Table properties for the stream.
    """

    def __init__(self, table_name: str, descriptor_proto: Descriptor):
        self.table_name = table_name
        self.descriptor_proto = descriptor_proto


class StreamConfigurationOptions:
    """
    Configuration options for the stream.
    """

    def __init__(self, **kwargs):
        # Set default values for attributes

        # Maximum number of records that can be sent to the server before waiting for acknowledgment
        self.max_inflight_records: int = 50_000

        # Whether to enable automatic recovery of the stream in case of failure
        self.recovery: bool = True

        # Timeout for stream recovery in milliseconds (for one attempt of recovery).
        # Total timeout = recovery_timeout_ms * recovery_retries
        self.recovery_timout_ms: int = 15000

        # Backoff time in milliseconds between recovery attempts
        self.recovery_backoff_ms: int = 2000

        # Number of retries for stream recovery
        self.recovery_retries: int = 3

        # The number of ms in which, if we do not receive an acknowledgement from the server, the server will be considered unresponsive
        self.server_lack_of_ack_timeout_ms: int = 60000

        # Timeout for flushing the stream in milliseconds (5 minutes default)
        self.flush_timeout_ms: int = 300_000

        self.ack_callback: Optional[Callable[[IngestRecordResponse], None]] = None

        # Dynamically update attributes based on kwargs
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)


class StreamState(Enum):
    UNINITIALIZED = 0  # Before stream is created/opened
    OPENED = 1  # Stream is opened and ready to send records
    FLUSHING = 2  # Stream is flushing records
    CLOSED = 3  # Stream is gracefully closed
    RECOVERING = 4  # Stream is recovering from an error
    FAILED = 5  # Stream is closed due to an error


class ZerobusException(Exception):
    """
    Base class for all exceptions in the Zerobus SDK.
    """

    def __init__(self, message: str):
        super().__init__(message)


class NonRetriableException(ZerobusException):
    """
    Inherits from ZerobusException and indicates a non-retriable error has occurred.
    """

    pass


class _StreamFailureType(Enum):
    UNKNOWN = 0
    SENDER_ERROR = 1
    RECEIVER_ERROR = 2
    SERVER_UNRESPONSIVE = 3


class _StreamFailureInfo:
    def __init__(self):
        self.failure_counts = 0
        self.failure_type = _StreamFailureType.UNKNOWN

    def log_failure(self, failure_type: _StreamFailureType):
        if self.failure_type == failure_type:
            self.failure_counts += 1
        else:
            self.failure_counts = 1
            self.failure_type = failure_type

    def reset_failure(self, failure_type: _StreamFailureType):
        if self.failure_type == failure_type:
            self.failure_counts = 0
            self.failure_type = _StreamFailureType.UNKNOWN
